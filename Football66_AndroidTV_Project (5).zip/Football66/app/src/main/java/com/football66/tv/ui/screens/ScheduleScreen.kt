package com.football66.tv.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.football66.tv.data.model.Match
import com.football66.tv.ui.theme.CardBackground
import com.football66.tv.ui.theme.DarkBackground
import com.football66.tv.ui.theme.FocusGreen
import com.football66.tv.ui.theme.TextGray
import com.football66.tv.ui.theme.TextWhite

@Composable
fun ScheduleScreen(
    matches: List<Match>,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 64.dp, vertical = 40.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "📅 LỊCH THI ĐẤU",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = FocusGreen
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "[BACK] Quay lại",
                fontSize = 16.sp,
                color = TextGray
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            items(matches) { match ->
                ScheduleCard(match = match)
            }
        }
    }
}

@Composable
private fun ScheduleCard(match: Match) {
    var isFocused by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.03f else 1.0f,
        animationSpec = tween(durationMillis = 150),
        label = "ScheduleFocusScale"
    )

    Box(
        modifier = Modifier
            .scale(scale)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBackground)
            .border(
                width = if (isFocused) 3.dp else 1.dp,
                color = if (isFocused) FocusGreen else Color(0xFF222222),
                shape = RoundedCornerShape(12.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = match.tournament,
                    fontSize = 14.sp,
                    color = FocusGreen,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "${match.homeTeam} vs ${match.awayTeam}",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF222222))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = match.timeOrStatus,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextWhite
                )
            }
        }
    }
}