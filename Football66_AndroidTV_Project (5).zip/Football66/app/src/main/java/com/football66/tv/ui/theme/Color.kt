package com.football66.tv.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF000000)
val CardBackground = Color(0xFF111111)
val FocusGreen = Color(0xFF00E676)
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFFAAAAAA)
val CardBorder = Color(0xFF222222)