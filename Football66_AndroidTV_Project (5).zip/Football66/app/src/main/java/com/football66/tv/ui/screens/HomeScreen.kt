package com.football66.tv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.football66.tv.ui.components.TVMenuItemCard
import com.football66.tv.ui.theme.DarkBackground
import com.football66.tv.ui.theme.FocusGreen
import com.football66.tv.viewmodel.Screen

@Composable
fun HomeScreen(
    onNavigate: (Screen) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 64.dp, vertical = 48.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "FOOTBALL 66",
            fontSize = 40.sp,
            fontWeight = FontWeight.Black,
            color = FocusGreen,
            letterSpacing = 2.sp
        )
        Text(
            text = "Ứng dụng xem trực tiếp & lịch thi đấu bóng đá",
            fontSize = 16.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(48.dp))

        Column(
            modifier = Modifier.width(480.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            TVMenuItemCard(
                title = "▶  XEM BÓNG ĐÁ",
                onClick = { onNavigate(Screen.WATCH) }
            )

            TVMenuItemCard(
                title = "📅  LỊCH THI ĐẤU",
                onClick = { onNavigate(Screen.SCHEDULE) }
            )

            TVMenuItemCard(
                title = "⚙  CÀI ĐẶT",
                onClick = { onNavigate(Screen.SETTINGS) }
            )
        }
    }
}