package com.football66.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.football66.tv.ui.screens.HomeScreen
import com.football66.tv.ui.screens.ScheduleScreen
import com.football66.tv.ui.screens.SettingsScreen
import com.football66.tv.ui.screens.WatchScreen
import com.football66.tv.ui.theme.DarkBackground
import com.football66.tv.ui.theme.Football66Theme
import com.football66.tv.viewmodel.MainViewModel
import com.football66.tv.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Football66Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    Football66App(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun Football66App(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    if (uiState.currentScreen != Screen.HOME) {
        BackHandler {
            viewModel.navigateTo(Screen.HOME)
        }
    }

    when (uiState.currentScreen) {
        Screen.HOME -> HomeScreen(
            onNavigate = { screen -> viewModel.navigateTo(screen) }
        )
        Screen.WATCH -> WatchScreen(
            matches = uiState.liveMatches,
            onBack = { viewModel.navigateTo(Screen.HOME) }
        )
        Screen.SCHEDULE -> ScheduleScreen(
            matches = uiState.upcomingMatches,
            onBack = { viewModel.navigateTo(Screen.HOME) }
        )
        Screen.SETTINGS -> SettingsScreen(
            onBack = { viewModel.navigateTo(Screen.HOME) }
        )
    }
}