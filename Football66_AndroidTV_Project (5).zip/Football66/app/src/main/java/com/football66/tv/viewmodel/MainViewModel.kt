package com.football66.tv.viewmodel

import androidx.lifecycle.ViewModel
import com.football66.tv.data.FootballRepository
import com.football66.tv.data.model.Match
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class Screen {
    HOME, WATCH, SCHEDULE, SETTINGS
}

data class UiState(
    val currentScreen: Screen = Screen.HOME,
    val liveMatches: List<Match> = emptyList(),
    val upcomingMatches: List<Match> = emptyList(),
    val selectedMatch: Match? = null
)

class MainViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        _uiState.value = _uiState.value.copy(
            liveMatches = FootballRepository.getLiveMatches(),
            upcomingMatches = FootballRepository.getUpcomingMatches()
        )
    }

    fun navigateTo(screen: Screen) {
        _uiState.value = _uiState.value.copy(currentScreen = screen)
    }

    fun selectMatch(match: Match) {
        _uiState.value = _uiState.value.copy(selectedMatch = match)
    }
}