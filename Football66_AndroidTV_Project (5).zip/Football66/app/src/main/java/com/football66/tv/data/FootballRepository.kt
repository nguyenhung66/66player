package com.football66.tv.data

import com.football66.tv.data.model.Match

object FootballRepository {
    fun getLiveMatches(): List<Match> {
        return listOf(
            Match(
                id = "m1",
                homeTeam = "Real Madrid",
                awayTeam = "Barcelona",
                homeScore = "2",
                awayScore = "1",
                timeOrStatus = "75'",
                tournament = "El Clásico - La Liga",
                isLive = true
            ),
            Match(
                id = "m2",
                homeTeam = "Manchester City",
                awayTeam = "Arsenal",
                homeScore = "1",
                awayScore = "1",
                timeOrStatus = "60'",
                tournament = "Premier League",
                isLive = true
            ),
            Match(
                id = "m3",
                homeTeam = "Vietnam",
                awayTeam = "Thailand",
                homeScore = "3",
                awayScore = "0",
                timeOrStatus = "88'",
                tournament = "AFF Cup",
                isLive = true
            ),
            Match(
                id = "m4",
                homeTeam = "Bayern Munich",
                awayTeam = "Dortmund",
                homeScore = "0",
                awayScore = "0",
                timeOrStatus = "32'",
                tournament = "Bundesliga",
                isLive = true
            )
        )
    }

    fun getUpcomingMatches(): List<Match> {
        return listOf(
            Match(
                id = "s1",
                homeTeam = "Liverpool",
                awayTeam = "Chelsea",
                timeOrStatus = "23:30 - Hôm nay",
                tournament = "Premier League"
            ),
            Match(
                id = "s2",
                homeTeam = "Inter Milan",
                awayTeam = "AC Milan",
                timeOrStatus = "02:45 - Ngày mai",
                tournament = "Serie A"
            ),
            Match(
                id = "s3",
                homeTeam = "PSG",
                awayTeam = "Marseille",
                timeOrStatus = "02:00 - Ngày mai",
                tournament = "Ligue 1"
            ),
            Match(
                id = "s4",
                homeTeam = "U23 Việt Nam",
                awayTeam = "U23 Nhật Bản",
                timeOrStatus = "19:00 - Ngày 24/07",
                tournament = "U23 Châu Á"
            )
        )
    }
}