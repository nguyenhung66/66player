package com.football66.tv.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = FocusGreen,
    background = DarkBackground,
    surface = CardBackground,
    onPrimary = DarkBackground,
    onBackground = TextWhite,
    onSurface = TextWhite
)

@Composable
fun Football66Theme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}