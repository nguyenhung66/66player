package com.football66.tv.data.model

data class Match(
    val id: String,
    val homeTeam: String,
    val awayTeam: String,
    val homeScore: String = "-",
    val awayScore: String = "-",
    val timeOrStatus: String,
    val tournament: String,
    val isLive: Boolean = false,
    val streamUrl: String = ""
)