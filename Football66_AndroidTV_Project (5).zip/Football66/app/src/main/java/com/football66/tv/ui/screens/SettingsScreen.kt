package com.football66.tv.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.football66.tv.ui.theme.CardBackground
import com.football66.tv.ui.theme.DarkBackground
import com.football66.tv.ui.theme.FocusGreen
import com.football66.tv.ui.theme.TextGray
import com.football66.tv.ui.theme.TextWhite

@Composable
fun SettingsScreen(
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 64.dp, vertical = 40.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚙ CÀI ĐẶT",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = FocusGreen
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "[BACK] Quay lại",
                fontSize = 16.sp,
                color = TextGray
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth(0.6f)
        ) {
            SettingItem(title = "Chất lượng mặc định", value = "1080p Full HD")
            SettingItem(title = "Chế độ phát", value = "Media3 ExoPlayer")
            SettingItem(title = "Tự động chọn máy chủ", value = "Bật")
            SettingItem(title = "Phiên bản ứng dụng", value = "v1.0.0 (Football66 TV)")
        }
    }
}

@Composable
private fun SettingItem(title: String, value: String) {
    var isFocused by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.03f else 1.0f,
        animationSpec = tween(durationMillis = 150),
        label = "SettingFocusScale"
    )

    Box(
        modifier = Modifier
            .scale(scale)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBackground)
            .border(
                width = if (isFocused) 3.dp else 1.dp,
                color = if (isFocused) FocusGreen else Color(0xFF222222),
                shape = RoundedCornerShape(12.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextWhite
            )
            Text(
                text = value,
                fontSize = 16.sp,
                color = FocusGreen
            )
        }
    }
}