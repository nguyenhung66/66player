# Proguard rules
-keep class com.football66.tv.** { *; }